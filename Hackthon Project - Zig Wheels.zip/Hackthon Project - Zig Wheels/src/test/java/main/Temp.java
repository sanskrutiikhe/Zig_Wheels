package main;

public class Temp {

	public static void main(String[] args) {
		
		String[] data = new String[2];
		data[0] = "Rs. 79,000";
		data[1] = "Rs. 4.79 Lakh";
		for(String d : data) {
			if(d.contains("Lakh")) {
				d = d.replaceAll("Rs. ", "");
				double out = Double.parseDouble(d.replaceAll("[^0-9.]", ""));
				out = out*100000;
				System.out.println(out);
			}
			else {
				System.out.println(Double.parseDouble(d.replaceAll("[^0-9]", "")));
			}
		}
		

	
		 
	}
}
